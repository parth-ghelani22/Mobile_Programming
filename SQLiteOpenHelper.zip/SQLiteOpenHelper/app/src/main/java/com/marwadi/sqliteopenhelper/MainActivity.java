package com.marwadi.sqliteopenhelper;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText e_name, e_contact, e_add;
    Button b_add, b_edit, b_del, b_view;
    SQLLite sqlLite;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e_name = findViewById(R.id.name);
        e_contact = findViewById(R.id.contact);
        e_add = findViewById(R.id.address);

        b_add = findViewById(R.id.b_ins);
        b_edit = findViewById(R.id.b_edit);
        b_del = findViewById(R.id.b_del);
        b_view = findViewById(R.id.b_view);

        sqlLite = new SQLLite(this);

        b_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = e_name.getText().toString();
                String contact = e_contact.getText().toString();
                String address = e_add.getText().toString();

                sqlLite.insertData(name, contact, address);
                Toast.makeText(MainActivity.this, "Data Inserted successfully!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}