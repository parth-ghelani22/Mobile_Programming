package com.example.radio;

import android.os.Bundle;
import android.util.TypedValue;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ToggleButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    TextView tv;
    CheckBox cb;

    ToggleButton tg;

    Switch sw;


    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        tv = findViewById(R.id.textView);
        cb = findViewById(R.id.checkbox1);
        tg = findViewById(R.id.toggleButton);
        sw= findViewById(R.id.switch1);


        // Define a shared listener to avoid repeating code 3 times
        CompoundButton.OnCheckedChangeListener sizeChangeListener = new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // Get current size in PIXELS
                float currentSizePx = tv.getTextSize();

                // Define the change amount (5 pixels)
                float change = 5.0f;

                if (isChecked) {
                    // Set size specifying we are using PIXELS
                    tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, currentSizePx + change);
                } else {
                    tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, currentSizePx - change);
                }
            }
        };

        // Attach the same listener to all toggleable views
        cb.setOnCheckedChangeListener(sizeChangeListener);
        tg.setOnCheckedChangeListener(sizeChangeListener);
        sw.setOnCheckedChangeListener(sizeChangeListener);
    }
}