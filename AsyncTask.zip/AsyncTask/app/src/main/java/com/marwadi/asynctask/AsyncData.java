package com.marwadi.asynctask;

import android.app.AlertDialog;
import android.content.Context;
import android.os.AsyncTask;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

public class AsyncData extends AsyncTask<String,Integer,String> {
    Context localContext;
    AlertDialog.Builder builder;
    public AsyncData(MainActivity globalContext) {
        localContext = globalContext;
    }
    @Override
    protected void onPreExecute() {
    builder = new AlertDialog.Builder(localContext);
    }
@Override
protected String doInBackground(String... strings){

    String data = strings[0];
    try {
        Thread.sleep(2000);
    } catch (InterruptedException e) {
        throw new RuntimeException(e);
    }
    return data;
    }

    @Override
    protected void onPostExecute(String data) {
        builder.setMessage(data)
                .setTitle("Async Task Example")
                .setCancelable(true)
                .setIcon(R.drawable.ic_launcher_background)
                .show();

    }
}


